"""Mandatory, consistently named SI spectra and a concise human-readable run card."""
import json,os,shutil,fcntl
from pathlib import Path
import numpy as np
from scipy.integrate import simpson
from pulses import Pulse
from surface_storage import atomic_json

def pulse_rows(config):
    result=[]
    for i,entry in enumerate(config['pulses']):
        p=Pulse(**entry['pulse']);result.append({'number':i+1,'polarization':entry.get('polarization','z'),**p.__dict__,
                'duration_au':p.duration,'duration_fs':p.duration*.0241888432659,
                'intensity_FWHM_fs':p.duration*.0241888432659*2*np.arccos(2**(-.25))/np.pi,
                'equivalent_cycle_average_peak_intensity_W_cm2':3.5094452e16*p.field**2})
    return result

def publish(out,run_id):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    out=Path(out);meta=json.loads((out/'run.json').read_text())
    if not meta.get('complete'):raise ValueError('cannot label an incomplete propagation as a final SI spectrum')
    with np.load(out/'spectrum.npz') as loaded:d={k:loaded[k] for k in loaded.files}
    if str(d['source_signature'])!=meta['signature']:raise ValueError('spectrum/configuration mismatch')
    e=d['energy'];P=d['angle_integrated'];total=P.sum(axis=0);labels=list(map(tuple,d['labels']))
    if not np.isfinite(P).all() or np.any(P<0):raise ValueError('invalid spectrum')
    windows=[]
    for low,high in [(.18,.42),(.52,.68)]:
        mask=(e>=low)&(e<=high)
        if mask.sum()<3:
            windows.append({'window':[low,high],'available':False,'peak_height':None,'peak_energy_grid':None,'yield':None,'channel_yields':None});continue
        y=simpson(P[:,mask],x=e[mask],axis=1)
        windows.append({'window':[low,high],'available':True,'peak_height':float(total[mask].max()),'peak_energy_grid':float(e[mask][total[mask].argmax()]),
                        'yield':float(sum(y)),'channel_yields':y.tolist()})
    target=labels.index((2,1,1)) if (2,1,1) in labels else None
    fraction=windows[0]['channel_yields'][target]/windows[0]['yield'] if target is not None and windows[0]['yield'] and windows[0]['yield']>0 else None
    both=all(w['available'] for w in windows)
    ratio=windows[0]['peak_height']/windows[1]['peak_height'] if both and windows[1]['peak_height'] else None
    yr=windows[0]['yield']/windows[1]['yield'] if both and windows[1]['yield'] else None
    applicable=bool(configured:=meta['config'].get('design')) and len(meta['config']['pulses'])>=2
    transfer=json.loads((out/'ionic_transfer.json').read_text()) if (out/'ionic_transfer.json').exists() else {}
    result={'run_id':run_id,'configuration_signature':meta['signature'],'complete':True,'labels':d['labels'].tolist(),'bands':windows,
            'peak_height_ratio_03_over_06':ratio,'yield_ratio_03_over_06':yr,'old_band_2p_plus1_fraction':fraction,
            'predeclared_targets':{'peak_height_ratio_min':3.,'band_yield_ratio_min':5.,'old_band_2p_plus1_fraction_min':.95},
            'target_applicable':applicable,
            'target_passed':bool(ratio is not None and yr is not None and fraction is not None and ratio>=3 and yr>=5 and fraction>=.95) if applicable else None,
            'scope':'Sum of explicitly recorded bound ionic channels, plus channel-resolved SI spectra; no claim of complete ionic-channel or spatial convergence.',
            'pulses':pulse_rows(meta['config']),'ionic_transfer':transfer}
    atomic_json(out/'observables.json',result)
    data_name=f'{run_id}__single_ionization_spectrum.npz';destination=out/data_name
    if destination.exists():destination.unlink()
    try:os.link(out/'spectrum.npz',destination)
    except OSError:shutil.copy2(out/'spectrum.npz',destination)
    table=np.column_stack([e,total,*P]);header='energy_au,total_recorded_SI,'+','.join(f'n{n}_l{l}_m{m:+d}' for n,l,m in labels)
    np.savetxt(out/f'{run_id}__single_ionization_spectrum.csv',table,delimiter=',',header=header,comments='')
    fig,axes=plt.subplots(2,1,figsize=(10,8),layout='constrained',gridspec_kw={'height_ratios':[2,1]})
    for ax in axes:
        ax.plot(e,total,color='black',lw=1.6,label='SI: sum of recorded ionic channels')
        for label,color in [((1,0,0),'C0'),((2,1,1),'C3'),((2,1,0),'C2')]:
            if label in labels:ax.plot(e,P[labels.index(label)],color=color,lw=1.1,label=f'ion (n,l,m)={label}')
        ax.axvspan(.18,.42,color='C0',alpha=.07);ax.axvspan(.52,.68,color='C3',alpha=.07);ax.grid(alpha=.18)
        ax.set(xlabel='Electron energy (a.u.)',ylabel='dP / dE (a.u.)')
    axes[0].set_xlim((.1,.78) if both else (e[0],e[-1]));axes[0].set_ylim(bottom=0);axes[0].legend(fontsize=8)
    axes[0].set_title(f'Absolute SI spectrum | peak ratio {ratio:.2f}, band-yield ratio {yr:.2f}\nOld-band ion 2p(+1) fraction: {fraction:.4f}' if fraction is not None and ratio is not None and yr is not None else 'Absolute single-ionization spectrum')
    axes[1].set_yscale('log');axes[1].set_xlim(e[0],e[-1]);axes[1].set_ylim(max(total.max()*1e-8,1e-14),max(total.max()*1.5,1e-12))
    pulses=result['pulses'];title='; '.join(f"{p['polarization']}: w={p['omega']:g}, F={p['field']:.5g}, N={p['cycles']:g}, start={p['start']:g}" for p in pulses)
    fig.suptitle(run_id+'\n'+title,fontsize=9)
    figures=out/'figures';figures.mkdir(exist_ok=True);figure=figures/f'{run_id}__single_ionization_spectrum'
    for suffix in ['png','pdf']:
        temp=figure.with_name(figure.name+'.tmp.'+suffix);fig.savefig(temp,dpi=220);os.replace(temp,Path(str(figure)+'.'+suffix))
    plt.close(fig)
    resources=json.loads((out/'resource_estimate.json').read_text()) if (out/'resource_estimate.json').exists() else {}
    lines=[f'# {run_id}','',f"输入参数：`input.json`（签名 `{meta['signature']}`）。",'',
           f'数据：`{data_name}`；同名 CSV 可直接作图。',f'主图：`figures/{run_id}__single_ionization_spectrum.png`（另有 PDF）。','',
           '图中各曲线使用同一绝对概率密度刻度，未按各自峰高归一化。总谱仅求和已记录的束缚离子通道。','',
           '| 脉冲 | 偏振 | ω / a.u. | F / a.u. | 周期数 | 起点 / a.u. | 支撑宽度 / fs |','|---|---|---:|---:|---:|---:|---:|']
    for p in pulses:lines.append(f"| {p['number']} | {p['polarization']} | {p['omega']:.8g} | {p['field']:.8g} | {p['cycles']:g} | {p['start']:g} | {p['duration_fs']:.4f} |")
    lines+=['','`F` 为线偏振峰值电场；圆偏振两个分量各为 F/√2，具有相同周期平均强度。包络为 sin²。',
            '`dt`、径向网格、lmax、total_Lmax 和离子通道均在 input.json；这些是待继续收敛的数值参数。','',
            f'0.3/0.6 峰高比：{ratio}；能区积分产额比：{yr}（None 表示该能区未计算）。',
            f'旧能区 2p+1 条件份额：{fraction}。详细通道与准备态离子转移见 observables.json。',
            f"是否达到本次三项设计目标：{result['target_passed']}。该标志不等于完整数值收敛。",'',
            f"存储模式：{meta.get('surface_storage','legacy')}；文件上限：{meta.get('max_file_bytes',5000000000)} 字节。",
            f"资源估算：resource_estimate.json；预计持久数组 {resources.get('persistent_output_estimate_bytes','unknown')} 字节。"]
    (out/'RUN.md').write_text('\n'.join(lines)+'\n')
    return result

def update_index(root):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    with (root/'.index.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        rows=[]
        for folder in sorted(root.iterdir()):
            if not folder.is_dir() or not (folder/'STATUS.json').exists():continue
            status=json.loads((folder/'STATUS.json').read_text());c=json.loads((folder/'input.json').read_text())
            obs=json.loads((folder/'observables.json').read_text()) if (folder/'observables.json').exists() else {}
            rows.append({'run_id':folder.name,'state':status['state'],'input':str(folder.name+'/input.json'),
                'run_card':folder.name+'/RUN.md','figure':folder.name+'/'+status['figure'] if status.get('figure') else None,
                'spectrum':folder.name+'/'+status['spectrum'] if status.get('spectrum') else None,
                'pulses':pulse_rows(c),'peak_ratio':obs.get('peak_height_ratio_03_over_06'),
                'yield_ratio':obs.get('yield_ratio_03_over_06'),'old_2p_plus1_fraction':obs.get('old_band_2p_plus1_fraction'),
                'targets_passed':obs.get('target_passed')})
        atomic_json(root/'catalog.json',{'cases':rows,'note':'Only state=complete has the mandatory final spectrum and figures.'})
        text=['# 单电离谱结果索引','','每行是一份独立输入；完整参数在 input.json，参数含义和结果说明在 RUN.md。',
              '所有图采用绝对概率密度。同一配置重提会恢复检查点，不会新建一个伪重复结果。','',
              '| 模拟与输入 | 状态 | 主图 | 0.3/0.6 峰高比 | 能区产额比 | 旧能区 2p+1 份额 |',
              '|---|---|---|---:|---:|---:|']
        def number(x):return '—' if x is None else f'{x:.5g}'
        for r in rows:
            figure=f"[单电离谱]({r['figure']})" if r['figure'] else '等待完成'
            text.append(f"| [{r['run_id']}]({r['run_card']}) · [输入]({r['input']}) | {r['state']} | {figure} | {number(r['peak_ratio'])} | {number(r['yield_ratio'])} | {number(r['old_2p_plus1_fraction'])} |")
        (root/'INDEX.md').write_text('\n'.join(text)+'\n')
    return rows
